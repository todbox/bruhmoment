# Todbox
Todbox is a mod of Beepbox.co made by Just a Toad, in collaboration with Main Character of The Problem.


## Release Notes

Features listed with "~" are important features.

### 1.0.0 - 6/1/2021 (First release)
- Ported a BUNCH of new features from Mainbox that I'm too lazy to list here. ~
